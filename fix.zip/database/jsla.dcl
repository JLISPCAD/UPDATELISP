jsla_dialog : dialog {
  label = "JSLA - Selecao de Material";
  spacer;
  : list_box {
    key = "txt_list";
    width = 65;
    height = 25;
    allow_accept = false;
  }
  spacer;
  : edit_box {
    label = "Digite o numero do item:";
    key = "txt_num";
    edit_width = 8;
  }
  spacer;
  ok_cancel;
}
