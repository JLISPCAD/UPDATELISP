(defun c:RESETVARS ()
  ;; Interface e Caixas de Di�logo
  (setvar "FILEDIA" 1)      ; Caixas de di�logo para Abrir/Salvar arquivos
  (setvar "CMDDIA" 1)       ; Caixas de di�logo para comandos (Plot, Inser��o, etc.)
  (setvar "ATTDIA" 1)       ; Caixa de di�logo para preenchimento de Atributos de Blocos
  (setvar "EXPERT" 0)       ; Exibe avisos e confirma��es do sistema
  (setvar "SHORTCUTMENU" 11); Ativa menus de contexto padr�o de clique direito

  ;; Sele��o e Cursor
  (setvar "PICKFIRST" 1)    ; Permite selecionar objetos ANTES de chamar o comando
  (setvar "PICKAUTO" 1)     ; Ativa sele��o por janela automatica em espa�o vazio
  (setvar "HIGHLIGHT" 1)    ; Destaca graficamente os objetos selecionados
  (setvar "PICKBOX" 4)      ; Tamanho ideal do quadrado de sele��o do cursor
  (setvar "CURSORSIZE" 5)   ; Tamanho do cursor em cruz (use 100 se preferir a tela toda)

  ;; Edi��o e Blocos
  (setvar "DBLCLKEDIT" 1)   ; Ativa a edi��o por clique duplo global
  (setvar "BLOCKEDITLOCK" 0); Garante que o editor de blocos n�o esteja bloqueado

  ;; Comportamento de Comandos e Desenho
  (setvar "MIRRTEXT" 0)     ; N�o espelha nem inverte textos ao usar o comando MIRROR
  (setvar "EDGEMODE" 0)     ; Restringe TRIM e EXTEND apenas �s interse��es reais
  (setvar "DRAWORDERCTL" 3) ; Mantem a ordem correta de exibi��o dos objetos (Draw Order)

  ;; Refer�ncias Externas (XREFs)
  (setvar "VISRETAIN" 1)    ; Salva altera��es de camadas/cores feitas em XREFs
  (setvar "XLOADCTL" 2)     ; Otimiza performance e carregamento de XREFs

  (princ "\n[SUCESSO] Todas as variaveis padrao do AutoCAD foram restauradas!")
  (princ)
)

;; Executa automaticamente ao carregar
(c:RESETVARS)