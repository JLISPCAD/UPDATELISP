memoria : dialog {
    label = "Jlisp - Captura de Dados";
    
    spacer;
    : text {
        label = "Deseja capturar os dados do imovel no DWG?";
        alignment = centered;
    }
    spacer;

    ok_cancel;
}