geokml_dlg : dialog {
  label = "GEOKML";
  : row {
    : column {
      : boxed_column {
        label = "GOOGLE KML KMZ";
        : button { label = "Exportar para KML (Ekml)"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "IMPORTAR KML/KMLZ"; key = "btn_0_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "SHAPEFILE";
        : button { label = "Importar Shapefile (shp/zip)"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "Importar ShP e suas CLASSES  (shp/zip)"; key = "btn_1_1"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "SHAPEFILE COM HACHURA";
        : button { label = "Importar Shapefile com hachuras"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "Importar ShP e suas CLASSES HACHURA  (shp/zip)"; key = "btn_2_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "SHAPE DO CAR / SIRIEMA para KML";
        : button { label = "Zip do CAR para KML (sem fuso: Baixado do Siriema)"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "Zip do CAR para KML (com fuso: Inserido no Siriema)"; key = "btn_3_1"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "FERRAMENTAS";
        : button { label = "CONVERTER KML EM SHP"; key = "btn_4_0"; height = 3; fixed_width = false; }
        : button { label = "Unificar Hachuras por layer"; key = "btn_4_1"; height = 3; fixed_width = false; }
        : button { label = "Dividir shape unico em Classes  (shp/zip)"; key = "btn_4_2"; height = 3; fixed_width = false; }
        : button { label = "REPROJETAR FUSO DO SHAPE  (shp/zip)"; key = "btn_4_3"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
