nvert : dialog {
    label = "Numera��o de V�rtices - GEO";

    : row {
        : edit_box { label = "Prefixo:"; key = "prefixo"; edit_width = 20; }
        : toggle { label = "Desativar"; key = "desativar_prefixo"; }
    }
    : edit_box { label = "N�mero Inicial:"; key = "numero"; edit_width = 20; }
    : edit_box { label = "Tam. Texto:"; key = "txt_tam"; edit_width = 20; }

    // Campo de Pr�via (agora edit�vel: digitar aqui atualiza os campos acima)
    : edit_box { label = "Pr�via:"; key = "previa"; edit_width = 20; }

    : boxed_radio_column {
        label = "Tipo";
        : radio_button { label = "P - Ponto"; key = "P"; }
        : radio_button { label = "M - Marco"; key = "M"; }
        : radio_button { label = "V - V�rtice"; key = "V"; }
        : radio_button { label = "Customizado:"; key = "C"; }
    }
    : edit_box { label = "Valor customizado:"; key = "tipo_custom"; edit_width = 20; }

    : boxed_radio_column {
        label = "Modo de Opera��o";
        : radio_button { label = "Clique �nico"; key = "click_unico"; }
        : radio_button { label = "Polilinha (Mais ao Norte)"; key = "norte"; }
        : radio_button { label = "Polilinha (Trecho)"; key = "trecho"; }
    }

    : row {
        : button { label = "OK"; key = "accept"; is_default = true; }
        : button { label = "Cancelar"; key = "cancel"; is_cancel = true; }
    }
}
