memocsv6 : dialog {
  label = "MEMOCSV6 - Gerador de Memorial Descritivo via CSV";

  : boxed_column {
    label = "Dados do Imovel";
    : edit_box { label = "Imovel:"; key = "eb_imovel"; edit_width = 35; }
    : edit_box { label = "Proprietario:"; key = "eb_prop"; edit_width = 35; }
    : edit_box { label = "Municipio/UF:"; key = "eb_mun"; edit_width = 35; }
    : edit_box { label = "Matricula:"; key = "eb_mat"; edit_width = 35; }
    : edit_box { label = "Comarca:"; key = "eb_comarca"; edit_width = 35; }
  }

  : boxed_column {
    label = "Opcoes do Memorial";
    : popup_list { label = "Formato de Coordenadas:"; key = "pop_fmt"; edit_width = 30; }
    : toggle { label = "Incluir Altitudes no texto"; key = "t_alt"; }
    : toggle { label = "Incluir Confrontantes no texto"; key = "t_confr"; }
  }

  : boxed_column {
    label = "Parametros Tecnicos";
    : edit_box { label = "Fuso UTM:"; key = "eb_fuso"; edit_width = 6; }
    : edit_box { label = "Casas Decimais da Altura:"; key = "eb_dec_alt"; edit_width = 6; }
  }

  ok_cancel;
}