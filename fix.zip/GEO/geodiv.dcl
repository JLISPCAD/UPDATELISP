geodiv_dlg : dialog {
  label = "GEODIV";
  : row {
    : column {
      : boxed_column {
        label = "DIVIS�O DE AREA";
        : button { label = "JSPLIT - PROGRAMA DE DIVIS�O DE AREA"; key = "btn_0_0"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "DIVIS�O VIA LISP";
        : button { label = "DIVIDIR �REA AUTOMATICAMENTE"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "DIVIDIR AREA MANUAL"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "CORTAR PERIMETRO"; key = "btn_1_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "DIVIS�O VIA LISP REFERENCIA";
        : button { label = "REDUZIR APARTIR DE UMA V�RTICE"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "AMPLIAR AREA APARTIR DE UMA V�RTICE"; key = "btn_2_1"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
