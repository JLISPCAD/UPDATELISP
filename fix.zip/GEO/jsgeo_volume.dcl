jsgeo_vol_dlg : dialog {
  label = "JSGEO - C�LCULO DE VOLUME";
  : row {
    : column {
      : boxed_column {
        label = "Modelo Digital de Eleva��o";
        : button { label = "DEM - Carregar e Gerar Paleta"; key = "btn_mde1"; }
        : button { label = "DEM - Importar altura do"; key = "btn_mde2"; }
        : button { label = "DEM - Ajustar um trecho com cota escolhida"; key = "btn_mde3"; }
        : button { label = "Gerar Calculo (volume) da sua 3dpoly"; key = "btn_mde4"; }
      }
      : boxed_column {
        label = "JSGEO";
        : button { label = "JSLA - Definir tipo de material"; key = "btn_js1"; }
        : button { label = "JS - Setar volume para o layer atual"; key = "btn_js2"; }
        : button { label = "GERAR CALCULO DE ATERRO E TABELA"; key = "btn_js3"; }
      }
    }
    : column {
      : boxed_column {
        label = "TEXTO";
        : button { label = "CALCULAR TEXTO EM M3"; key = "btn_txt1"; }
        : button { label = "MEU DIRETORIO"; key = "btn_txt2"; }
      }
      : boxed_column {
        label = "DATABASE";
        : button { label = "GERAR DATABASE PADRAO"; key = "btn_db1"; }
        : button { label = "ALIMENTAR DATABASE VIASSS CAD"; key = "btn_db2"; }
        : button { label = "ALIMENTAR DATABASE MANUALMENTE"; key = "btn_db3"; }
      }
      : boxed_column {
        label = "PERFIL";
        : button { label = "Criar Perfil"; key = "btn_perf1"; }
        : button { label = "Carregar Perfil"; key = "btn_perf2"; }
      }
    }
  }
  cancel_button;
}
