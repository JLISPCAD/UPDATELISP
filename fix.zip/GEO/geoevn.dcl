geoevn_dlg : dialog {
  label = "EVN blocos (etiquetar)";
  : row {
    : column {
      : boxed_column {
        label = "ETIQUETAR V�RTICES";
        : button { label = "Inserir / Etiquetar V�rtices"; key = "btn_0_0"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "IMPORTAR CSV em BLOCOS";
        : button { label = "Gerar CSV vazio"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "Importar CSV Bloco"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "Importar apenas nome das v�rtices"; key = "btn_1_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "CONFRONTANTES - LIMITES";
        : button { label = "Mapear Confrontantes (mosaico Incra)"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "Renomeia o texto (captura layer de poligno)"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "Converte Layer de LIM-CONFRONTANTES em Blocos"; key = "btn_2_2"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
