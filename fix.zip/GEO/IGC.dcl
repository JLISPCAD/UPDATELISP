IGC : dialog {
  label = "Configuracao GEO - Comandos IG";
  
  : boxed_column {
    label = "Fuso UTM";
    : popup_list {
      key = "fuso_list";
      width = 20;
    }
  }

  : boxed_column {
    label = "Op��es de Desenho";
    : toggle {
      label = "Inserir ponto no desenho";
      key = "insere_ponto";
    }
    : toggle {
      label = "Inserir texto no ponto";
      key = "insere_texto";
    }
  }

  : boxed_column {
    label = "Par�metros do Texto";
    : edit_box {
      label = "Altura do Texto:";
      key = "altura_texto";
      edit_width = 10;
    }
    : edit_box {
      label = "Layer do Texto:";
      key = "layer_texto";
      edit_width = 20;
    }
  }

  spacer;
  ok_cancel;
}