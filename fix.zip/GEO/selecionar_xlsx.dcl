selecionar_xlsx : dialog {
  label = "Selecionar Perfil CSV - C:\\jlisp\\MAT";
  : boxed_column {
    label = "Perfis Dispon�veis";
    : radio_button { key = "p1"; label = "perfil 1: Latitude: 18 01 01,123 S Longitude: 57 01 01,123 W - com ou sem SW"; value = "1"; }
    : radio_button { key = "p2"; label = "perfil 2: Latitude: -18�01'01,123'' Longitude: -57�01'01,123'' - com sinal negativo e simbolos"; }
    : radio_button { key = "p3"; label = "perfil 3: E 429.825,32m N 7.917.208,64m - com ponto e virugula"; }
    : radio_button { key = "p4"; label = "perfil 4: E 429825,32 N 7917208,64 - somente com ponto (padr�o)"; }
    : radio_button { key = "p5"; label = "perfil 5: E 42982532 791720864 - vc definie as casas"; }
  }
  ok_cancel;
}