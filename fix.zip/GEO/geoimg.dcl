geoimg_dlg : dialog {
  label = "GEOIMG";
  : row {
    : column {
      : boxed_column {
        label = "BAIXAR IMAGEM DE SAT�LITE";
        : button { label = "GOOGLE"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "DSG - CARTA DO EXERCITO"; key = "btn_0_1"; height = 3; fixed_width = false; }
        : button { label = "IMAGEM SENTINEL"; key = "btn_0_2"; height = 3; fixed_width = false; }
        : button { label = "IMAGEM do ARCGIS Esri"; key = "btn_0_3"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "IMPORTAR BAIXADA DE SAT�LITE";
        : button { label = "GOOGLE"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "DSG - CARTA DO EXERCITO"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "IMAGEM SENTINEL"; key = "btn_1_2"; height = 3; fixed_width = false; }
        : button { label = "IMAGEM do ARCGIS Esri"; key = "btn_1_3"; height = 3; fixed_width = false; }
        : button { label = "Importar imagem com JGW"; key = "btn_1_4"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "TEMATICOS FUSO21S";
        : button { label = "DERSUL 2026 21S"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "Hidrografia 21S"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "Solos 21S"; key = "btn_2_2"; height = 3; fixed_width = false; }
        : button { label = "Relevo 21S"; key = "btn_2_3"; height = 3; fixed_width = false; }
        : button { label = "Vegeta��o 21s"; key = "btn_2_4"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "TEMATICOS FUSO22S";
        : button { label = "DERSUL 2026 22S"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "Hidrografia 22S"; key = "btn_3_1"; height = 3; fixed_width = false; }
        : button { label = "Solos 22S"; key = "btn_3_2"; height = 3; fixed_width = false; }
        : button { label = "Relevo 22S"; key = "btn_3_3"; height = 3; fixed_width = false; }
        : button { label = "Vegeta��o 22S"; key = "btn_3_4"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
