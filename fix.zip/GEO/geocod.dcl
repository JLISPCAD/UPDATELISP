geocod_dlg : dialog {
  label = "GEOCOD";
  : spacer { height = 1; fixed_height = true; }
  : row {
    alignment = top;
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "LATITUDE E LONGITUDE";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "UTM PARA GMS - (com Relatorio)"; key = "btn_0_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
      : spacer { height = 1; fixed_height = true; }
      : boxed_column {
        label = "LATITUDE E LONGITUDE DECIMAL";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "UTM PARA LATLONG DEC - (com Relatorio)"; key = "btn_1_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "ID UTM PARA LATLONG DEC - (RAPIDO)"; key = "btn_1_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "ID UTM PARA LATLONG DEC - (CONFIG FUSO)"; key = "btn_1_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "LAN�AR COORDENADAS";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Lancar coordenadas geogr�ficas (latitude e longitude)"; key = "btn_2_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Lancar coordenadas geogr�ficas (decimal)"; key = "btn_2_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
      : spacer { height = 1; fixed_height = true; }
      : boxed_column {
        label = "MATRICULAS";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "(Programa) UTM/GMS  Extrair Matricula"; key = "btn_3_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "(Programa)  Azimute e Rumo"; key = "btn_3_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "IMPORTAR CSV";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar UTM"; key = "btn_4_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar GMS"; key = "btn_4_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar Rumo"; key = "btn_4_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar Azimute"; key = "btn_4_3"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar Rumo (antigo LISP)"; key = "btn_4_4"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar Azimute (Antigo LISP)"; key = "btn_4_5"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "UNITS - AUTOCAD";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "AZIMUTE"; key = "btn_6_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "RUMO"; key = "btn_6_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "GRAUS DECIMAIS (padr�o do Autocad)"; key = "btn_6_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
      : spacer { height = 1; fixed_height = true; }
      : boxed_column {
        label = "FERRAMENTAS";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "CONVERSOR DE DATUM"; key = "btn_5_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Cotar Rumo e Distancia"; key = "btn_5_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Reconstruir Polilinha no sentido Horario"; key = "btn_5_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
  }
  : spacer { height = 1; fixed_height = true; }
  : row {
    : spacer { }
    : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 14; fixed_width = true; }
    : spacer { }
  }
}
