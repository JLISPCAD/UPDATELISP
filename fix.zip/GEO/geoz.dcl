geoz_dlg : dialog {
  label = "GEOZ";
  : row {
    : column {
      : boxed_column {
        label = "3D PARA 2D";
        : button { label = "CONVERTER 3D PARA 2D"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "REMOVER VALOR Z da polilinha"; key = "btn_0_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "EXTRAI DADOS";
        : button { label = "Extrair pontosZ de blocos"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "Extrai altura de area3d em pontos"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "Extrai TEXTOS (valor Z) de pontos selecionados"; key = "btn_1_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "GERAR 3DPOLYLINE";
        : button { label = "GERA 3DPolyline ca�ando POINTs e BLOCOS (INSERT)"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "GERA 3DPolyline ca�ando TEXTOS (com filtro de Layers e distancia)"; key = "btn_2_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "FERRAMENTAS";
        : button { label = "INSERE (valor Z) de pontos: APARTIR DE TEXTOS PROXIMOS"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "REMOVE TUDO QUE N�O � NUMERO DE TEXTOS"; key = "btn_3_1"; height = 3; fixed_width = false; }
        : button { label = "SUBSTITUI -Virgula POR -Ponto EM TEXTOS"; key = "btn_3_2"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
