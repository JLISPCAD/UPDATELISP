memocsv5 : dialog {
  label = "MEMOCSV5 - Configuracao da Tabela";
  
  : boxed_column {
    label = "Selecione os campos a importar:";
    : toggle { label = "Vertice (Nome)"; key = "t_vert"; }
    : toggle { label = "Coordenadas UTM (E / N)"; key = "t_utm"; }
    : toggle { label = "Latitude / Longitude"; key = "t_latlong"; }
    : toggle { label = "Altitudes"; key = "t_alt"; }
    : toggle { label = "Azimute"; key = "t_az"; }
    : toggle { label = "Distancia"; key = "t_dist"; }
    : toggle { label = "Confrontante"; key = "t_confr"; }
  }

  : boxed_column {
    label = "Casas Decimais";
    : edit_box { label = "UTM:"; key = "dec_utm"; edit_width = 6; }
    : edit_box { label = "Altura:"; key = "dec_alt"; edit_width = 6; }
  }

  : boxed_column {
    label = "Parametros do Desenho";
    : edit_box { label = "Altura do Texto:"; key = "txt_altura"; edit_width = 6; }
  }

  ok_cancel;
}