jsgeo_menu_dlg : dialog {
  label = "Painel JSGEO - Menu Principal";
  : boxed_column {
    label = "JSGEO - CALCULO DE VOLUME";
    : button { label = "DEM - Carregar e Gerar Paleta"; key = "btn_dem1"; }
    : button { label = "DEM - Importar altura do"; key = "btn_dem2"; }
    : button { label = "DEM - Ajustar um trecho com cota escolhida"; key = "btn_dem3"; }
    : button { label = "Gerar Calculo (volume) da sua 3dpoly"; key = "btn_dem4"; }
  }
  : boxed_column {
    label = "Utilitários e Desenho";
    : button { label = "Desenho MGP / Croqui e outros"; key = "btn_desenho"; }
    : button { label = "Coordenadas / Matriculas"; key = "btn_coord"; }
    : button { label = "TOPODATA"; key = "btn_topodata"; }
    : button { label = "Cota Z ou Poligono 3D"; key = "btn_cotaz"; }
  }
  : boxed_column {
    label = "Ferramentas e Edição";
    : button { label = "Cotar, medir ou Inserir"; key = "btn_cotar"; }
    : button { label = "Divisao e Calculo"; key = "btn_divisao"; }
    : button { label = "REPROJETAR / CONVERTER"; key = "btn_reproj"; }
    : button { label = "GPS"; key = "btn_gps"; }
  }
  : boxed_column {
    label = "Configuração e Limpeza";
    : button { label = "Configuração"; key = "btn_config"; }
    : button { label = "Abrir Diretorio DWG"; key = "btn_dir"; }
    : button { label = "Gerar DWG limpo"; key = "btn_dwglimpo"; }
    : button { label = "Limpar desenho (Xrefs, imagens, Purge)"; key = "btn_limpar"; }
  }
  ok_only;
}
