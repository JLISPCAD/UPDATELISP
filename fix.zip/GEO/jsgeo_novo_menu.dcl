jsgeo_novo_menu_dlg : dialog {
  label = "MENU DE COMANDOS";
  : row {
    : column {
      : boxed_column {
        label = "EKML";
        : button { label = "EKML TESTE"; key = "btn_0_0"; }
        : button { label = "IKML"; key = "btn_0_1"; }
      }
    }
  }
  cancel_button;
}
