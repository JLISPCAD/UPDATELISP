geosigef_dlg : dialog {
  label = "Sigef e Incra";
  : row {
    : column {
      : boxed_column {
        label = "Importar Mosaico Sigef";
        : button { label = "IMPORTAR VIZINHOS DO MOSAICO DO INCRA"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "Importa lista v�rtices GERADAS"; key = "btn_0_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "MEMOSIGEF ODS";
        : button { label = "Gerar CSV estilo SIGEF"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "Visualizar CSV estilo SIGEF"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "Atualizar blocos apartir de um CSV"; key = "btn_1_2"; height = 3; fixed_width = false; }
        : button { label = "Importar CSV limpo"; key = "btn_1_3"; height = 3; fixed_width = false; }
        : button { label = "Cruzador de Memosigef e EXTERNOS"; key = "btn_1_4"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "Calculo SGL (BLOCOS)";
        : button { label = "Calculo SGL (BLOCOS)"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "Calculo SGL (PontosZ ou area3D)"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "Calculo SGL (ods ou planilha)"; key = "btn_2_2"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "IMPORTAR ODS";
        : button { label = "Importar Area SIGEF (ODS) GMS"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "Importar Area SIGEF (ODS) UTM"; key = "btn_3_1"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "IMPORTAR CSV DOS SIGEF";
        : button { label = "Importar Area SIGEF (CSV) GMS"; key = "btn_4_0"; height = 3; fixed_width = false; }
        : button { label = "Importar Area SIGEF (CSV) UTM"; key = "btn_4_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "Converter ODS";
        : button { label = "ODS para KML"; key = "btn_5_0"; height = 3; fixed_width = false; }
        : button { label = "ODS para Excel"; key = "btn_5_1"; height = 3; fixed_width = false; }
        : button { label = "ODS para Shape"; key = "btn_5_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "FERRAMENTAS";
        : button { label = "Reconstruir CSV do SIGEF em XLS"; key = "btn_6_0"; height = 3; fixed_width = false; }
        : button { label = "MEMORIAL DESCRITIVO APARTIR DO MEMORIAL PDF DO SIGEF"; key = "btn_6_1"; height = 3; fixed_width = false; }
        : button { label = "Desbloquear ODS protegida"; key = "btn_6_2"; height = 3; fixed_width = false; }
        : button { label = "Cruzador ODS e Memosigef"; key = "btn_6_3"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
