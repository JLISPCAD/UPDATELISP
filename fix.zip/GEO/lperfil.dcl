lperfil_dlg : dialog {
  label = "Gerenciador de Perfis - Importar";
  spacer;
  : text {
    value = "Selecione o perfil desejado:";
  }
  : list_box {
    key = "lista_import";
    width = 35;
    height = 10;
    allow_accept = true;
  }
  spacer;
  ok_cancel;
}
