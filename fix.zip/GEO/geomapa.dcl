geomapa_dlg : dialog {
  label = "DESENHO MGP CROQUI PRANCHA E OUTROS";
  : row {
    : column {
      : boxed_column {
        label = "DESENHOS MGP GERAL";
        : button { label = "Gerar Croqui de Acesso"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "INSERIR PRANCHA / QUADRO"; key = "btn_0_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "INSERIR GRADE UTM";
        : button { label = "INSERIR GRADE UTM (fechada)"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "INSERIR GRADE UTM (aberta)"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "APAGAR GRADE UTM INSERIDA"; key = "btn_1_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "IMAGEM DE LOCALIZA��O AGESUL";
        : button { label = "AGESUL - Fuso 21S"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "AGESUL - Fuso 22S"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "Recortar imagem para Carta Situa��o"; key = "btn_2_2"; height = 3; fixed_width = false; }
        : button { label = "Recortar Imagem para Poligono (ADMASK)"; key = "btn_2_3"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
