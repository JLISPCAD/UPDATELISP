memocsv_preview : dialog {
  label = "Visualizador de Tabela CSV - Modo Grid";
  
  : boxed_column {
    label = "Conteudo Atual do CSV na Memoria";
    : list_box {
      key = "lb_csv_data";
      width = 150;
      height = 18;
      fixed_width_font = true;
    }
  }

  : row {
    : button {
      key = "btn_open_csv";
      label = "Abrir CSV Carregado";
      width = 22;
    }
    spacer;
    : ok_button {
      label = "Fechar";
      is_default = true;
      width = 12;
    }
  }
}