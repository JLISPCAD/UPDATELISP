jsgeo_sat_dlg : dialog {
  label = "DOWNLOAD IMAGENS DE SAT�LITE";
  : row {
    : column {
      : boxed_column {
        label = "GOOGLE / CARTAS DSG";
        : button { label = "Baixar imagem do Google"; key = "btn_g1"; }
        : button { label = "Importar imagem do google"; key = "btn_g2"; }
        spacer;
        : button { label = "BAIXAR CARTA DO EXERCITO"; key = "btn_c1"; }
        : button { label = "IMPORTAR CARTA DO EXERCITO BAIXADA"; key = "btn_c2"; }
      }
      : boxed_column {
        label = "SENTINEL / ARCGIS esri";
        : button { label = "BAIXAR IMAGEM SENTINEL"; key = "btn_s1"; }
        : button { label = "CARREGAR IMAGEM SENTINEL"; key = "btn_s2"; }
        spacer;
        : button { label = "Baixar imagem do ARCGIS esri"; key = "btn_a1"; }
        : button { label = "Importar imagem"; key = "btn_a2"; }
      }
    }
    : column {
      : boxed_column {
        label = "TEMAS - Fuso 21";
        : button { label = "DERSUL 2026 21S"; key = "btn_t21_1"; }
        : button { label = "Hidrografia 21"; key = "btn_t21_2"; }
        : button { label = "Solos 21"; key = "btn_t21_3"; }
        : button { label = "Relevo 21"; key = "btn_t21_4"; }
        : button { label = "Vegeta��o 21s"; key = "btn_t21_5"; }
      }
      : boxed_column {
        label = "TEMAS - Fuso 22 & Diversos";
        : button { label = "DERSUL 2026 22S"; key = "btn_t22_1"; }
        : button { label = "Hidrografia 22"; key = "btn_t22_2"; }
        : button { label = "Solos 22"; key = "btn_t22_3"; }
        : button { label = "Vegeta��o 22s"; key = "btn_t22_4"; }
        spacer;
        : button { label = "Importar imagem com JGW"; key = "btn_jgw"; }
      }
    }
  }
  cancel_button;
}
