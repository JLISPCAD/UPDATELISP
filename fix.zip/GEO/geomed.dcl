geomed_dlg : dialog {
  label = "GEOMED";
  : row {
    : column {
      : boxed_column {
        label = "COTAR";
        : button { label = "Cotar Rumo e Distancia"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "Cotar Distancia (com filtro)"; key = "btn_0_1"; height = 3; fixed_width = false; }
        : button { label = "Cotar Distancia (Trecho total)"; key = "btn_0_2"; height = 3; fixed_width = false; }
        : button { label = "Cotar Distancia (distancia total)"; key = "btn_0_3"; height = 3; fixed_width = false; }
        : button { label = "Inserir ESTACAS por Metros"; key = "btn_0_4"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "CALCULO DE AREAS";
        : button { label = "AT -  Exibe calculo de Pol�gnos selecionado"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "TAD - Soma ATIVA de Pol�gonos (CLOSED)"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "TADA - Soma ATIVA de Pol�gonos (CLOSED/ABERTO)"; key = "btn_1_2"; height = 3; fixed_width = false; }
        : button { label = "TADR - DESATIVA SOMA ATIVA TAD OU TADA"; key = "btn_1_3"; height = 3; fixed_width = false; }
        : button { label = "AFP � Simula o desenhar poligono"; key = "btn_1_4"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "CALCULO DE AREAS (INSERIR AREAS)";
        : button { label = "ATA - Inserir Areas (incluindo Aberto)"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "PLA - Inserir Areas em HA"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "PLA - Inserir Areas em HA e PERIMETRO"; key = "btn_2_2"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "CALCULO DE TEXTOS";
        : button { label = "SNT - Soma de texto"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "SNP - Soma de texto (Insere o resultado)"; key = "btn_3_1"; height = 3; fixed_width = false; }
        : button { label = "SNC - Soma e Subtra��o de texto (acumulativo)"; key = "btn_3_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "CALCULO DE LAYERS";
        : button { label = "LC - Subtrair valor de Layer selecionado"; key = "btn_4_0"; height = 3; fixed_width = false; }
        : button { label = "Criar Layer pronto de soma e subtra��o"; key = "btn_4_1"; height = 3; fixed_width = false; }
        : button { label = "Calc - Calcular Layer Pronto"; key = "btn_4_2"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "NUMERAR - INDEXAR E CALCULAR";
        : button { label = "Numerar Inserir e Calcular Areas Numeradas"; key = "btn_5_0"; height = 3; fixed_width = false; }
        : button { label = "Renomear Numera��o (Incremento)"; key = "btn_5_1"; height = 3; fixed_width = false; }
        : button { label = "Numerar Inserir e Calcular Areas (por layer)"; key = "btn_5_2"; height = 3; fixed_width = false; }
        : button { label = "Calcular layers de areas Numeradas (por layer)"; key = "btn_5_3"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
