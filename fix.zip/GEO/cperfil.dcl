cperfil_dlg : dialog {
  label = "Gerenciador de Perfis - Exportar";
  spacer;
  : text {
    value = "Nome do novo perfil:";
  }
  : edit_box {
    key = "txt_nome";
    edit_width = 30;
  }
  spacer;
  : text {
    value = "Perfis salvos anteriormente:";
  }
  : list_box {
    key = "lista_perfis";
    width = 35;
    height = 8;
    allow_accept = true;
  }
  spacer;
  : button {
    label = "Excluir Perfil Selecionado";
    key = "btn_del";
  }
  spacer;
  ok_cancel;
}
