geoblocos_dlg : dialog {
  label = "Blocos (Nome Limites e altZ)";
  : row {
    : column {
      : boxed_column {
        label = "TEXTO PARA BLOCOS - Nome V�rtices- Limites ou AltZ";
        : button { label = "BUSCA SELETIVA (PERIMETRO)"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "Busca automatica (per�metro)"; key = "btn_0_1"; height = 3; fixed_width = false; }
        : button { label = "Manual - Escolhe texto depois v�rtices"; key = "btn_0_2"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "PONTOS PARA BLOCOS - ALTZ - ALT";
        : button { label = "Converte pontos com Z em bloco"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "busca pontos com Z no perimetro e converte"; key = "btn_1_1"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "CONFRONTANTES E LIMITES";
        : button { label = "Mapear Confrontantes (mosaico Incra ou CAR)"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "Renomeia o texto (captura layer de poligno)"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "Converte Layer de LIM-CONFRONTANTES em Blocos"; key = "btn_2_2"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "ALINHAR BLOCOS NO DESENHO";
        : button { label = "No Perimetro todo"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "Selecionados"; key = "btn_3_1"; height = 3; fixed_width = false; }
        : button { label = "Clonar formata��o de um bloco para outro"; key = "btn_3_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "MUDAR ESTILO DE BLOCOS";
        : button { label = "PADRAO PARA SIGEF"; key = "btn_4_0"; height = 3; fixed_width = false; }
        : button { label = "SIGEF PARA PADRAO"; key = "btn_4_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "ORGANIZAR";
        : button { label = "Deixar s� o Bloco V�rtice Vis�vel"; key = "btn_5_0"; height = 3; fixed_width = false; }
        : button { label = "Aumentar o tamanho do texto dos blocos"; key = "btn_5_1"; height = 3; fixed_width = false; }
        : button { label = "Extrair valor do Bloco em texto"; key = "btn_5_2"; height = 3; fixed_width = false; }
        : button { label = "Mover todos os blocos do layer 0"; key = "btn_5_3"; height = 3; fixed_width = false; }
        : button { label = "Selecionar bloco e todo seu conteudo"; key = "btn_5_4"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
