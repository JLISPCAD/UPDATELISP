geotpr_dlg : dialog {
  label = "GEOTPR";
  : spacer { height = 1; fixed_height = true; }
  : row {
    alignment = top;
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "TEXTOS";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "TCS - Alterar texto (Maiusculas e Minusculas)"; key = "btn_0_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "TXOUT - EXPORTA TEXTOS SELECIONADOS"; key = "btn_0_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Aumentar Todos os Textos do Layer"; key = "btn_0_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Substituir palavas"; key = "btn_0_3"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "RL - MOSTRA O CALCULO DE 20% DE UM TEXTO"; key = "btn_0_4"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "SUBSTITUI -Virgula POR -Ponto EM TEXTOS"; key = "btn_0_5"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Remove tudo que n�o  � NUMERO"; key = "btn_0_6"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
      : spacer { height = 1; fixed_height = true; }
      : boxed_column {
        label = "POLILINHAS - V�RTICES";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Pontuar polilinha (indice)"; key = "btn_2_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Inserir pontos em todas v�rtices da Polilinha"; key = "btn_2_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "POLILINHAS AREA";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Region para Polilinha"; key = "btn_1_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "3D PARA 2D"; key = "btn_1_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Unificar Poligonos (areas) - Remembrar"; key = "btn_1_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Redesenha trecho da Polilinha"; key = "btn_1_3"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Reconstruir Polilinha no sentido Horario"; key = "btn_1_4"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Remover V�rtices Duplicadas"; key = "btn_1_5"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "IPL - INSERE V�RTICE EM UM POL�GONO"; key = "btn_1_6"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "RPL - REMOVE V�RTICE DE UM POL�GONO"; key = "btn_1_7"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
    : column {
      alignment = top;
      fixed_height = true;
      : boxed_column {
        label = "POLILINHAS OUTROS";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "PJ:  Unir linhas, arco em Pol�gono."; key = "btn_3_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Refaz Pol�gono sentido + ao Norte/horario"; key = "btn_3_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Selecionar polilinhas abertas"; key = "btn_3_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Offset duplo"; key = "btn_3_3"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
      : spacer { height = 1; fixed_height = true; }
      : boxed_column {
        label = "RASTER";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Georreferenciar uma imagem CARREGADA com JGW"; key = "btn_4_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Importar imagem com JGW"; key = "btn_4_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Gerar Coordenadas (JGW)"; key = "btn_4_2"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
      : spacer { height = 1; fixed_height = true; }
      : boxed_column {
        label = "RASTER OUTROS";
        fixed_height = true;
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Recortar imagem para PASTA"; key = "btn_5_0"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
        : button { label = "Obriga imagem a caber no poligono"; key = "btn_5_1"; height = 2; fixed_width = false; fixed_height = true; }
        : spacer { height = 0.3; fixed_height = true; }
      }
    }
  }
  : spacer { height = 1; fixed_height = true; }
  : row {
    : spacer { }
    : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 14; fixed_width = true; }
    : spacer { }
  }
}
