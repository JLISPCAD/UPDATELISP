jsgeo_dlg : dialog {
  label = "MODELO DIGITAL DE ELEVA��O - DEM";
  : row {
    : column {
      : boxed_column {
        label = "MANIPULA��O DO DEM";
        : button { label = "DEM - Carregar e Gerar Paleta"; key = "btn_0_0"; height = 3; fixed_width = false; }
        : button { label = "DEM - Importar altura do DEM"; key = "btn_0_1"; height = 3; fixed_width = false; }
        : button { label = "DEM - Ajustar um trecho com cota escolhida"; key = "btn_0_2"; height = 3; fixed_width = false; }
        : button { label = "GERAR VOLUME de sua 3dpoly individual"; key = "btn_0_3"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "MANIPULA��O DE MATERIAL";
        : button { label = "JSLA - Definir tipo de material"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "JS - Setar volume para o layer atual"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "GERAR CALCULO DE VOLUME (GERAL) COM TABELA"; key = "btn_1_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "PERFIL DE TRABALHO";
        : button { label = "CRIAR PERFIL"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "CARREGAR PERFIL"; key = "btn_2_1"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "FERRAMENTAS";
        : button { label = "CALCULAR TEXTO EM M3"; key = "btn_3_0"; height = 3; fixed_width = false; }
        : button { label = "GERAR DATABASE PADRAO"; key = "btn_3_1"; height = 3; fixed_width = false; }
        : button { label = "ALIMENTAR DATABASE VIA CAD"; key = "btn_3_2"; height = 3; fixed_width = false; }
        : button { label = "ALIMENTAR DATABASE MANUALMENTE"; key = "btn_3_3"; height = 3; fixed_width = false; }
        : button { label = "DEFINIR DIRETORIO DO DWG COMO PADRAO"; key = "btn_3_4"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
