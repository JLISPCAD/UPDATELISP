geomemo_dlg : dialog {
  label = "Roteiros - Planilhas - Memorial";
  : row {
    : column {
      : boxed_column {
        label = "MEMORIAL PADR�O";
        : button { label = "Gerar Memoriais (com confrontantes)"; key = "btn_0_0"; height = 3; fixed_width = false; }
        spacer;
      }
      : boxed_column {
        label = "PLANILHAS";
        : button { label = "Gerar CSV Inicial"; key = "btn_1_0"; height = 3; fixed_width = false; }
        : button { label = "Inserir tabela CSV no Cad"; key = "btn_1_1"; height = 3; fixed_width = false; }
        : button { label = "Gerar memorial descritivo do CSV"; key = "btn_1_2"; height = 3; fixed_width = false; }
        spacer;
      }
    } 
    : column {
      : boxed_column {
        label = "PLANILHAS ATUALIZAR DADOS";
        : button { label = "Nome Vertices"; key = "btn_2_0"; height = 3; fixed_width = false; }
        : button { label = "Altura Z"; key = "btn_2_1"; height = 3; fixed_width = false; }
        : button { label = "Confrontantes"; key = "btn_2_2"; height = 3; fixed_width = false; }
        : button { label = "Coordenadas"; key = "btn_2_3"; height = 3; fixed_width = false; }
        spacer;
      }
    }
  }
  cancel_button;
}
