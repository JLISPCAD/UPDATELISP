(setvar "PROXYNOTICE" 0)

(setvar "PROXYSHOW" 0)
(setvar "NOMUTT" 0)

(princ)
(repeat 30
  (princ "\n--------------------")
)

(load "C:\\jLISP\\start3.fas")
   