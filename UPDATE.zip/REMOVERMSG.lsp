(setvar "TRUSTEDPATHS"
  (strcat
    (getvar "TRUSTEDPATHS")
    "C:\\jlisp"
    "C:\\jlisp\\Cartas"
    "C:\\jlisp\\GEO"
    "C:\\jlisp\\GEO\\Shape"
  )
)


   