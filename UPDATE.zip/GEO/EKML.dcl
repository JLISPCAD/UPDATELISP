ekml_dialog : dialog { 
    label = "JCAD - Exportar Google Earth";
    : boxed_radio_column {
        label = "Datum";
        key = "datum_radio";
        : radio_button { key = "sirgas"; label = "SIRGAS 2000"; }
        : radio_button { key = "sad69"; label = "SAD69"; }
    }
    : column { 
        label = "Fuso";
        : edit_box { key = "fuso_eb"; label = "Fuso UTM:"; edit_width = 10; }
    }
    spacer;
    ok_cancel;
}