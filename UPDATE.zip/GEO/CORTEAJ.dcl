corteaj_dialog : dialog {
    label = "CORTEAJ - Corte por Azimute com Desconto de Ilhas";
    
    : column {
        : edit_box {
            label = "�rea L�quida Desejada (Hectares):";
            key = "eb_area";
            edit_width = 10;
        }
        
        : spacer { height = 1; }
        
        : edit_box {
            label = "Altura do Texto:";
            key = "eb_alt";
            edit_width = 10;
        }
        
        : spacer { height = 1; }
        
        : boxed_column {
            label = "Como Funciona o Desconto:";
            : text { label = "O motor vai mover a linha paralela e"; }
            : text { label = "subtrair automaticamente a area das ilhas"; }
            : text { label = "internas que forem cortadas pelo alinhamento."; }
        }
    }
    
    : spacer { height = 1; }
    
    : row {
        fixed_width = true;
        alignment = centered;
        : button { label = "Selecionar Gleba"; key = "accept"; is_default = true; width = 12; }
        : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 12; }
    }
}