// ==============================================================================
// DI�LOGO PARA O GERADOR DE MEMORIAL DESCRITIVO (MEMOJH)
// Arquivo: C:\jlisp\GEO\memojh.dcl
// ==============================================================================

memojh_dialog : dialog {
  label = "Memorial Descritivo Geod�sico - MEMOJH";
  width = 85;
  spacer;

  : boxed_column {
    label = "Dados Gerais do Im�vel";
    
    : edit_box { key = "eb_imovel"; label = "Nome do Im�vel:"; edit_width = 55; }
    : edit_box { key = "eb_prop"; label = "Propriet�rio:"; edit_width = 55; }
    : edit_box { key = "eb_mun"; label = "Munic�pio / UF:"; edit_width = 55; }
    : edit_box { key = "eb_mat"; label = "Matr�cula / C�digo:"; edit_width = 55; }
    : edit_box { key = "eb_comarca"; label = "Comarca:"; edit_width = 55; }
  }

  spacer;

  : boxed_column {
    label = "Configura��es Geogr�ficas e Formata��o - (Para gerar ALTURA no memorial, escolha 3dpolyline no DESENHO)";
    
    : edit_box {
      key = "eb_fuso";
      label = "Fuso UTM:";
      edit_width = 10;
      value = "21";
    }

    : popup_list {
      key = "pop_fmt";
      label = "Perfil de Formata��o:";
      width = 65;
    }

    : popup_list {
      key = "pop_dec_alt";
      label = "Casas Decimais da Altitude:";
      width = 25;
    }

    : edit_box {
      key = "eb_dist";
      label = "Raio p/ Confrontantes (m):";
      edit_width = 10;
    }
  }

  spacer;

  : row {
    : boxed_radio_column {
      label = "Modo de Sele��o";
      : radio_button { key = "rb_ind"; label = "Individual"; }
      : radio_button { key = "rb_mult"; label = "M�ltiplas Polilinhas"; }
    }

    : boxed_radio_column {
      label = "V�rtice Inicial";
      : radio_button { key = "rb_norte"; label = "Mais ao Norte"; }
      : radio_button { key = "rb_manual"; label = "Clique Manual"; }
    }
  }

  spacer;
  ok_cancel;
}