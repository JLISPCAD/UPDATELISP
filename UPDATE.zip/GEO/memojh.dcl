// ==============================================================================
// DI�LOGO PARA O GERADOR DE MEMORIAL DESCRITIVO (MEMOJH)
// Arquivo: C:\jlisp\GEO\memojh.dcl
// ==============================================================================

memojh_dialog : dialog {
  label = "Memorial Descritivo Geod�sico - MEMOJH";
  width = 78;

  // ---------------------------------------------------------------------------
  // DADOS DO IM�VEL
  // ---------------------------------------------------------------------------
  : boxed_column {
    label = "Dados Gerais do Im�vel";

    : edit_box {
      key = "eb_imovel";
      label = "Nome do Im�vel:";
      edit_width = 50;
    }

    : edit_box {
      key = "eb_prop";
      label = "Propriet�rio:";
      edit_width = 50;
    }

    : edit_box {
      key = "eb_mun";
      label = "Munic�pio / UF:";
      edit_width = 50;
    }

    : edit_box {
      key = "eb_mat";
      label = "Matr�cula / C�digo:";
      edit_width = 50;
    }

    : edit_box {
      key = "eb_comarca";
      label = "Comarca:";
      edit_width = 50;
    }
  }

  // ---------------------------------------------------------------------------
  // CONFIGURA��ES
  // ---------------------------------------------------------------------------
  : boxed_row {
    label = "Configura��es Geogr�ficas";

    : popup_list {
      key = "pop_fmt";
      label = "Perfil:";
      width = 28;
    }

    : edit_box {
      key = "eb_fuso";
      label = "Fuso:";
      edit_width = 4;
      value = "21";
    }

    : popup_list {
      key = "pop_dec_alt";
      label = "Altura:";
      width = 14;
    }
  }

  // ---------------------------------------------------------------------------
  // INSTRU��ES
  // ---------------------------------------------------------------------------
  : boxed_row {
    label = "Instru��es para altura e confrontantes";

    : column {

      : text {
        label = "ODS IMPORTADA";
      }

      : text {
        label = "� Ative Layer ods_bloco_altura";
        color = red;
      }

      : text {
        label = "� Ative Layer ds_bloco_confrontante";
        color = red;
      }

      : text {
        label = "� Ative Layer ods_bloco_nomevertice";
        color = red;
      }
    }

    : column {

      : text {
        label = "DESENHO LIMPO";
      }

      : text {
        label = "� NVERT     - Cria bloco de nomes";
        color = red;
      }

      : text {
        label = "� LIM           - Cria bloco de Confrontantes";
        color = red;
      }

      : text {
        label = "� ALTZ        - Cria bloco de Altura (converte pontos selecionados)";
        color = red;
      }

      : text {
        label = "� ALTZ2      - Cria bloco de Alturas do per�metro (captura os pontos)";
        color = red;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // OP��ES
  // ---------------------------------------------------------------------------
  : row {

    : boxed_radio_column {
      label = "Modo de Sele��o";

      : radio_button {
        key = "rb_ind";
        label = "Individual";
      }

      : radio_button {
        key = "rb_mult";
        label = "M�ltiplas Polilinhas";
      }
    }

    : boxed_radio_column {
      label = "V�rtice Inicial";

      : radio_button {
        key = "rb_norte";
        label = "Mais ao Norte";
      }

      : radio_button {
        key = "rb_manual";
        label = "Clique Manual";
      }
    }
  }

  ok_cancel;
}