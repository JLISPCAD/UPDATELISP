geotool_dialog : dialog {
  label = "GEOP - UTM para Geogr�fica";

  : row {
    : boxed_column {
      label = "Fuso UTM";
      : edit_box { key = "utm_zone"; label = "Fuso:"; value = "22"; width = 10; fixed_width = true; }
    }
    : boxed_radio_column {
      label = "Hemisf�rio";
      : radio_button { key = "hemi_s"; label = "Sul (S)"; value = "1"; }
      : radio_button { key = "hemi_n"; label = "Norte (N)"; }
    }
  }

  : toggle { key = "show_utm";       label = "Mostrar coordenadas UTM (E e N)"; value = "1"; }
  : toggle { key = "show_prefix";    label = "Mostrar prefixos (E:, N:, Lat:, Long:)"; value = "1"; }
  : toggle { key = "side_by_side";   label = "Lat. e Long. na mesma linha"; }
  : toggle { key = "show_azimute";   label = "Incluir Azimute no CSV"; value = "0"; }
  : toggle { key = "show_distancia"; label = "Incluir Dist�ncia no CSV"; value = "0"; }

  : boxed_radio_column {
    label = "Formato das Coordenadas Geogr�ficas";
    : radio_button { key = "fmt_symbols"; label = "Com s�mbolos (� ' \")"; value = "1"; }
    : radio_button { key = "fmt_numbers"; label = "Somente n�meros e espa�os"; }
  }

  : button { key = "btn_csv"; label = "Gerar CSV da Polilinha"; width = 30; fixed_width = true; }
  ok_cancel;
}