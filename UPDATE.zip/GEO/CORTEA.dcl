cortea_dialog : dialog {
    label = "CORTEA - Corte por Azimute / �ngulo Fixo";
    
    : column {
        : edit_box {
            label = "�rea Desejada (Hectares):";
            key = "eb_area";
            edit_width = 10;
        }
        
        : spacer { height = 1; }
        
        : edit_box {
            label = "Altura do Texto:";
            key = "eb_alt";
            edit_width = 10;
        }
        
        : spacer { height = 1; }
        
        : boxed_column {
            label = "Guia de Orienta��o do Vetor:";
            : text { label = "Se o corte for horizontal (Oeste -> Leste):"; }
            : text { label = "  � LADO ESQUERDO = NORTE (Em Cima)"; }
            : text { label = "  � LADO DIREITO = SUL (Em Baixo)"; }
            : spacer { height = 0.5; }
            : text { label = "A �rea final ser� gerada SEMPRE no"; }
            : text { label = "Lado Esquerdo (Norte / Em Cima) do seu vetor."; }
        }
    }
    
    : spacer { height = 1; }
    
    : row {
        fixed_width = true;
        alignment = centered;
        : button { label = "Definir �ngulo"; key = "accept"; is_default = true; width = 12; }
        : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 12; }
    }
}