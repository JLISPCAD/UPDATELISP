gerenciador : dialog {
    label = "Gerenciador de Rotinas (LSP)";
    : column {
        : row {
            : edit_box {
                label = "Pasta de origem:";
                key = "txt_pasta";
                width = 35;
            }
            : button {
                label = "Escolher Arquivo...";
                key = "btn_dir";
                width = 18;
            }
        }
        spacer;
        : popup_list {
            label = "1. Sele��o por Lista Suspensa:";
            key = "pop_arquivos";
            width = 45;
        }
        spacer;
        : list_box {
            label = "2. Sele��o por Caixa de Lista (List Box):";
            key = "lst_arquivos";
            height = 30;
            width = 45;
        }
        spacer;
        ok_cancel;
    }
}