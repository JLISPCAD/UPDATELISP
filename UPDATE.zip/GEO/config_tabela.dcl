config_tabela : dialog {
    label = "JJ Geoprocessamento - v2.3";
    : column {
        : boxed_column {
            label = "Operação";
            : radio_button { key = "click"; label = "Cotar por Clique"; value = "1"; }
            : radio_button { key = "poligono"; label = "Converter Polígono 2D para 3D"; }
            : radio_button { key = "tabela"; label = "Gerar Tabela e CSV (da 3DPoly)"; }
        }
        : boxed_column {
            label = "Memória";
            : button {
                label = "Limpar Cache de Pontos";
                key = "limpar";
            }
            : text { label = "O filtro agora é automático por área."; }
        }
    }
    : row {
        : button { label = "OK"; key = "ok"; is_default = true; width = 12; }
        : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 12; }
    }
}