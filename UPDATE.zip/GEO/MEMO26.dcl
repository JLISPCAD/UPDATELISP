memo26_dialog : dialog {
    label = "Memorial Descritivo Profissional";
    : column {
        : boxed_column {
            label = "Dados do Im�vel (Para o Word)";
            : edit_box { label = "Im�vel:"; key = "eb_imovel"; edit_width = 40; }
            : edit_box { label = "Propriet�rio:"; key = "eb_prop"; edit_width = 40; }
            : edit_box { label = "Munic�pio/UF:"; key = "eb_mun"; edit_width = 40; }
            : edit_box { label = "Matr�cula:"; key = "eb_mat"; edit_width = 20; }
            : edit_box { label = "Comarca:"; key = "eb_comarca"; edit_width = 40; }
        }

        : boxed_row {
            label = "Configura��es de Processamento";
            : radio_column {
                label = "In�cio por:";
                key = "rg_inicio";
                : radio_button { label = "V�rtice mais ao Norte"; key = "rb_norte"; }
                : radio_button { label = "Sele��o Manual (Clique)"; key = "rb_manual"; }
            }
            : radio_column {
                label = "Modo de Sele��o:";
                key = "rg_modo";
                : radio_button { label = "Individual (1 area)"; key = "rb_ind"; }
                : radio_button { label = "M�ltiplos (m�ltiplas �reas)"; key = "rb_mult"; }
            }
        }

        : boxed_column {
            label = "Suporte a Confronta��es";
            : text { label = "Busca textos exclusivamente no layer LIM-CONFRONTANTES."; }
            : edit_box { label = "Raio de busca (m):"; key = "eb_dist"; edit_width = 10; value = "15.0"; }
            : text { label = "Voc� pode usar o comando LIM para gerar confrontantes."; foreground = "blue"; }
        }
        
        : spacer { height = 0.5; }
        : text { label = "Certifique-se de que o Word esteja instalado."; alignment = centered; }
        : spacer { height = 1; }
    }
    ok_cancel;
}