dig_dialog : dialog {
    label = "Plotagem de Coordenadas - DIG";
    
    :boxed_column {
        label = "Par�metros Iniciais";
        
        :row {
            :text { label = "Fuso UTM:"; width = 15; }
            :edit_box { key = "fuso"; edit_width = 10; }
        }
        
        :row {
            :text { label = "Altura do Texto:"; width = 15; }
            :edit_box { key = "altura"; edit_width = 10; }
        }
        
        :row {
            :text { label = "Nome do V�rtice:"; width = 15; }
            :edit_box { key = "nome"; edit_width = 15; }
        }
    }
    
    ok_cancel;
}