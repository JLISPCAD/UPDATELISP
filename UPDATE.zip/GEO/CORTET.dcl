cortet_dialog : dialog {
    label = "CORTET - Divis�o de �reas Sniper";
    
    : column {
        : edit_box {
            label = "�rea Desejada (Hectares):";
            key = "eb_area";
            edit_width = 10;
        }
        
        : spacer { height = 1; }
        
        : boxed_radio_column {
            label = "Onde ficar� o alvo?";
            : radio_button { label = "Lado A (Vermelho)"; key = "rb_ladoa"; value = "1"; }
            : radio_button { label = "Lado B (Verde)"; key = "rb_ladob"; }
        }
        
        : spacer { height = 1; }
        
        : edit_box {
            label = "Altura do Texto:";
            key = "eb_alt";
            edit_width = 10;
        }
    }
    
    : spacer { height = 1; }
    
    : row {
        fixed_width = true;
        alignment = centered;
        : button { label = "Iniciar Corte"; key = "accept"; is_default = true; width = 12; }
        : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 12; }
    }
}