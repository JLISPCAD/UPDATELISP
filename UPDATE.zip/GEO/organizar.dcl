organizar_dialog : dialog {
    label = "Organizador de Layers Inteligente";
    
    : boxed_column {
        label = "Selecione o que deseja organizar e criar layer:";
        
        : toggle { label = "Textos e MTextos (Layer: texto)"; key = "chk_texto"; }
        : toggle { label = "Pontos (Layer: pontos)"; key = "chk_pontos"; }
        : toggle { label = "Linhas Simples (Layer: linhas)"; key = "chk_linhas"; }
        : toggle { label = "Polilinhas 2D / 3D (Layer: polilinhas)"; key = "chk_plines"; }
        : toggle { label = "C�rculos (Layer: circulos)"; key = "chk_circulos"; }
        : toggle { label = "Regi�es / Regions (Layer: regioes)"; key = "chk_regioes"; }
        : toggle { label = "Linhas 3D / 3DFace (Layer: linhas_3d)"; key = "chk_3dface"; }
        : toggle { label = "Hachuras (Layer: hachura)"; key = "chk_hachura"; }
        : toggle { label = "Imagens (Layer: imagens)"; key = "chk_imagens"; }
    }
    
    spacer;
    
    : row {
        fixed_width = true;
        alignment = centered;
        : button { label = "Organizar"; key = "accept"; is_default = true; width = 14; }
        : button { label = "Cancelar"; key = "cancel"; is_cancel = true; width = 14; }
    }
}