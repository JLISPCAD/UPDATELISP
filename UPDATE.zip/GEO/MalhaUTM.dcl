malha_dialog : dialog {
    label = "Configura��es da Malha UTM - Vers�o Final";
    
    : column {
        : boxed_column {
            label = "Modo Autom�tico";
            : toggle {
                label = "Ativar C�lculo Autom�tico";
                key = "tg_auto";
                value = "0"; 
            }
            : edit_box {
                label = "Dividir �rea por (Ex: 8, 10, 12):";
                key = "eb_div";
                edit_width = 10;
            }
        }
        
        : boxed_column {
            label = "Par�metros Manuais (Apenas se Auto estiver OFF)";
            : edit_box {
                label = "Intervalo da Malha:";
                key = "eb_int";
                edit_width = 10;
            }
            : edit_box {
                label = "Altura do Texto:";
                key = "eb_alt";
                edit_width = 10;
            }
        }
    }
    
    spacer;
    : row {
        fixed_width = true;
        alignment = centered;
        : button { label = "Selecionar Polilinha"; key = "accept"; is_default = true; width = 20; }
        : button { label = "Apagar Malha Existente"; key = "btn_erase"; width = 15; }
        : cancel_button { label = "Sair"; }
    }
}